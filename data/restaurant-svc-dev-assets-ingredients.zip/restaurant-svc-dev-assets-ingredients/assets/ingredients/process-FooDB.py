import json

with open("FooDB_Food.json") as json_file:
    foodb = json.load(json_file)

ingredient_names = []
ingredient_group = set()
ingredient_subgroup = set()
food_group_subgroups = {}

for ingredient in foodb:

    if ingredient["food_group"] == "Dishes":
        continue

    if ingredient["food_group"]:
        ingredient_group.add(ingredient["food_group"])

    if ingredient["food_subgroup"]:
        ingredient_subgroup.add(ingredient["food_subgroup"])

    if ingredient["name"] and not (
        ingredient["name"] in ingredient_group
        or ingredient["name"] in ingredient_subgroup
    ):

        exclude = [
            "Unclassified food or beverage",
            "Snack bar",
            "Nutritional drink",
            "Other frozen dessert",
            "Other fruit product",
            "Other bread product",
            "Other soy product",
            "Other cereal product",
            "Other bread",
            "Other alcoholic beverage",
            "Other wine",
            "Other snack food",
            "Other fish product",
            "Other beverage",
            "Other vegetable product",
            "Other candy",
            "Other animal fat",
            "Other cocoa product",
            "Other fermented milk",
            "Other frozen dessert",
            "French toast",
        ]

        if ingredient["name"] not in exclude:
            ingredient_names.append(ingredient["name"])

    if (
        ingredient["food_group"]
        and ingredient["food_subgroup"]
        and ingredient["food_group"] != ingredient["food_subgroup"]
    ):
        try:
            if (
                ingredient["food_subgroup"]
                not in food_group_subgroups[ingredient["food_group"]]
            ):
                food_group_subgroups[ingredient["food_group"]].append(
                    ingredient["food_subgroup"]
                )
        except:
            food_group_subgroups[ingredient["food_group"]] = [
                ingredient["food_subgroup"]
            ]


f = open("ingredient-name-enum.json", "w")
f.write(json.dumps(ingredient_names))
f.close()

f = open("food-group-enum.json", "w")
f.write(json.dumps(tuple(ingredient_group)))
f.close()

f = open("food-subgroup-enum.json", "w")
f.write(json.dumps(tuple(ingredient_subgroup)))
f.close()

f = open("food-group-subgroups.json", "w")
f.write(json.dumps(food_group_subgroups))
f.close()
