# Enumerated value sets

## Sources

### `ISO-languages.json`
Language names in English, ISO codes, and native language name representations sorted descending by estimated speaker population as of 2016: [http://cstrobbe.github.io/languagelearning/misc/languagetags.html](http://cstrobbe.github.io/languagelearning/misc/languagetags.html)

### `ISO-currencies.json`
Currency ISO Alpha3 codes pulled from Debian's 'pkg-isocodes'

### `postal-code.json`
See `modules/location` for specific information.

### `availability.json`, `order-status.json`, & `restricted-diets.json`
These are [Schema.org](http://www.schema.org) standard enumerated values.

### `role-enum`, `serves-cuisine.json`, `serves-style.json`, `serves-specialty.json`, etc...
These are custom enumerated values.

### `food-name-enum`, `food-group-enum`, `food-subgroup-enum`, & `food-group-subgroups`
Data ripped from FooDB project and Swiss Food Composition DB. See `enums/ingredients` for specific information.
