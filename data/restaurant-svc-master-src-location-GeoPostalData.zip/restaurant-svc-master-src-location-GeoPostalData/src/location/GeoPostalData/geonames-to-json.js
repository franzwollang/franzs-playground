const csv_parse = require ('csv-parse/lib/sync')
const fs = require ('fs')
const path = require ('path')
const { partial, pipe } = require('ramda')

function parseCSV(file){
  return csv_parse (fs.readFileSync(file), {
    skip_empty_lines: true,
    delimiter: '  '
  })
}

geonames = {
  'DE': './geonamesDE.csv',
  'AT': './geonamesAT.csv',
  'CH': './geonamesCH.csv'
};

function geonameSplit(array){
  return array.map( (arraySingle) => {
    return arraySingle[0].split('\t')
  })
}

geoname_keys = ['countryCode', 'postalCode', 'placeName', 'adminName1', 'adminCode1', 'adminName2', 'adminCode2', 'adminName3', 'adminCode3', 'latitude', 'longitude', 'accuracy']

function zip(arrays) {
    return arrays[0].map( (_,i) => {
        return arrays.map( (array) => {
          return array[i]})
    });
}

function zipCollect(keysArray, arrayOfArrays){
  return arrayOfArrays.reduce( (zippedArrays, valArray) => {
    zippedArrays.push( zip([keysArray, valArray]) );
    return zippedArrays;
  }, []);
}

function zipToKeyedObj(zippedArrays){
  // no magic numbers
  key_index = 0;
  value_index = 1;

  return zippedArrays.reduce( (keyed_objs, zip_array) => {
    compiled_obj = zip_array.reduce( (obj, zip_pair) => {
      obj[zip_pair[0]] = zip_pair[1]
      return obj
    }, {});

    keyed_objs.push(compiled_obj)
    return keyed_objs
  }, [])
}

function geonamesToObjJSON(geonames){
  transform = pipe(
    parseCSV,
    geonameSplit,
    partial(zipCollect, [geoname_keys]),
    zipToKeyedObj,
    JSON.stringify
  )
  return transform(geonames);
}

Object.keys(geonames).map( (key) => {
  fs.writeFileSync(`./geonames${key}.json`, geonamesToObjJSON(geonames[key]))
})
